# Ödev2 - Branching

Bu repo, veri okuma ve analiz için basit bir örnek içerir. Ana branch'te CSV verisi okunup özetlenmiştir.
