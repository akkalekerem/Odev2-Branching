import pandas as pd

# Veri setini oku
df = pd.read_csv("data.csv")

# Temel istatistiksel özet
print("Veri Özeti:")
print(df.describe())

# En yüksek notu alan kişi
max_score = df.loc[df['score'].idxmax()]
print(f"\nEn yüksek notu alan öğrenci: {max_score['name']} ({max_score['score']})")
